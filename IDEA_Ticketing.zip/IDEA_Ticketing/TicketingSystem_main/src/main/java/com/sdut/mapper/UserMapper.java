package com.sdut.mapper;

import com.sdut.pojo.User;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.springframework.stereotype.Repository;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author QHaoooLG
 * @since 2024-12-10
 */

@Repository
public interface UserMapper extends BaseMapper<User> {

}
