package com.sdut.service.impl;

import com.sdut.pojo.Pays;
import com.sdut.mapper.PaysMapper;
import com.sdut.service.IPaysService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author QHaoooLG
 * @since 2024-12-23
 */
@Service
public class PaysServiceImpl extends ServiceImpl<PaysMapper, Pays> implements IPaysService {

}
