INSERT INTO `list_ticket`(`scenery_id`, `ticket_id`) VALUES ('1', '1');
INSERT INTO `list_ticket`(`scenery_id`, `ticket_id`) VALUES ('2', '2');
INSERT INTO `list_ticket`(`scenery_id`, `ticket_id`) VALUES ('2', '3');
INSERT INTO `list_ticket`(`scenery_id`, `ticket_id`) VALUES ('1', '4');
INSERT INTO `list_ticket`(`scenery_id`, `ticket_id`) VALUES ('2', '4');
INSERT INTO `list_ticket`(`scenery_id`, `ticket_id`) VALUES ('1', '5');
INSERT INTO `list_ticket`(`scenery_id`, `ticket_id`) VALUES ('3', '6');
