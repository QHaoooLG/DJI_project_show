INSERT INTO `pays`(`id`, `amount`, `way`, `state`, `start_time`, `end_time`) VALUES ('1', 50.00, '微信支付', '已支付', '2024-12-07 20:33:56', '2024-12-07 21:34:08');
INSERT INTO `pays`(`id`, `amount`, `way`, `state`, `start_time`, `end_time`) VALUES ('2', 108.00, '微信支付', '未支付', '2024-12-02 22:04:42', '2024-12-02 23:03:45');
INSERT INTO `pays`(`id`, `amount`, `way`, `state`, `start_time`, `end_time`) VALUES ('3', 59.50, '微信支付', '已支付', '2024-12-04 22:41:33', '2024-12-04 22:41:39');
