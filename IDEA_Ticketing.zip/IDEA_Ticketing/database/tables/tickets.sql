INSERT INTO `tickets`(`id`, `price`, `num`, `discount`, `text`, `state`, `start_date`, `end_date`) VALUES ('1', 29.99, 300, 1.00, '学生票', '在售', '2024-10-01', '2024-11-30');
INSERT INTO `tickets`(`id`, `price`, `num`, `discount`, `text`, `state`, `start_date`, `end_date`) VALUES ('2', 65.00, 1000, 1.00, '成人票', '在售', '2024-10-01', '2024-11-30');
INSERT INTO `tickets`(`id`, `price`, `num`, `discount`, `text`, `state`, `start_date`, `end_date`) VALUES ('3', 35.00, 200, 0.85, '限时活动优惠学生票', '在售', '2024-12-01', '2024-12-31');
INSERT INTO `tickets`(`id`, `price`, `num`, `discount`, `text`, `state`, `start_date`, `end_date`) VALUES ('4', 25.00, 300, 1.00, '老年票', '在售', '2024-10-01', '2024-12-31');
INSERT INTO `tickets`(`id`, `price`, `num`, `discount`, `text`, `state`, `start_date`, `end_date`) VALUES ('5', 40.00, 200, 0.90, '限时活动优惠成人票', '在售', '2024-12-01', '2024-12-31');
INSERT INTO `tickets`(`id`, `price`, `num`, `discount`, `text`, `state`, `start_date`, `end_date`) VALUES ('6', 50.00, 300, 1.00, '长城普通票', '在售', '2024-10-01', '2024-12-31');
INSERT INTO `tickets`(`id`, `price`, `num`, `discount`, `text`, `state`, `start_date`, `end_date`) VALUES ('7', 80.00, 500, 1.00, '成人票', '在售', '2024-10-01', '2024-11-30');
