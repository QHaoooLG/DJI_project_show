INSERT INTO `list_person`(`booking_id`, `person_id`) VALUES ('1', '1');
INSERT INTO `list_person`(`booking_id`, `person_id`) VALUES ('2', '4');
INSERT INTO `list_person`(`booking_id`, `person_id`) VALUES ('2', '5');
INSERT INTO `list_person`(`booking_id`, `person_id`) VALUES ('2', '6');
