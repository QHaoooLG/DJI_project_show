INSERT INTO `loads`(`scenery_id`, `date`, `sold`, `max`) VALUES ('3', '2024-12-01', 100, 500);
INSERT INTO `loads`(`scenery_id`, `date`, `sold`, `max`) VALUES ('3', '2024-12-02', 200, 400);
