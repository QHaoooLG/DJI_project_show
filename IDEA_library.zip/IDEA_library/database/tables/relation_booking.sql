INSERT INTO `relation_booking`(`booking_id`, `pay_id`, `rebate_id`) VALUES ('1', '1', NULL);
INSERT INTO `relation_booking`(`booking_id`, `pay_id`, `rebate_id`) VALUES ('3', '3', NULL);
INSERT INTO `relation_booking`(`booking_id`, `pay_id`, `rebate_id`) VALUES ('2', '2', '1');
