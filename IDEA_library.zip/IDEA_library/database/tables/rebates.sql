INSERT INTO `rebates`(`id`, `start_time`, `end_time`, `state`) VALUES ('1', '2024-12-02 22:03:56', '2024-12-03 23:02:59', '已通过');
