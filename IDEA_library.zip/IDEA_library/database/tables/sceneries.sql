INSERT INTO `sceneries`(`id`, `name`, `text`, `start_date`, `end_date`, `img`) VALUES ('1', '泰山', '好高', '2024-12-01', '2024-12-31', 'c2625c26-2094-44ed-bbef-2782f0677a38.jpg');
INSERT INTO `sceneries`(`id`, `name`, `text`, `start_date`, `end_date`, `img`) VALUES ('2', '张家界', '好看', '2024-11-01', '2024-11-30', '31edf237-f6b7-42b2-b595-3af152c4993d.jpg');
INSERT INTO `sceneries`(`id`, `name`, `text`, `start_date`, `end_date`, `img`) VALUES ('3', '长城', '好爬', '2024-10-01', '2024-10-31', '73ba6d78-8586-44bd-91b5-1f3236a1241d.jpg');
INSERT INTO `sceneries`(`id`, `name`, `text`, `start_date`, `end_date`, `img`) VALUES ('4', '呼伦贝尔大草原', '好绿', '2024-11-01', '2024-12-31', '4ff368c4-5f7c-483e-b58e-4f77b216f0ea.jpg');
INSERT INTO `sceneries`(`id`, `name`, `text`, `start_date`, `end_date`, `img`) VALUES ('5', '苏州园林', '好美', '2024-10-01', '2024-12-31', '38e88908-b808-4c02-a24d-0d7b0cb571b4.jpg');
