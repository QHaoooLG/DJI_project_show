package com.sdut.service.impl;

import com.sdut.pojo.Loads;
import com.sdut.mapper.LoadsMapper;
import com.sdut.service.ILoadsService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author QHaoooLG
 * @since 2024-12-23
 */
@Service
public class LoadsServiceImpl extends ServiceImpl<LoadsMapper, Loads> implements ILoadsService {

}
