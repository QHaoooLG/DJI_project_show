package com.sdut.mapper;

import com.sdut.pojo.Pays;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author QHaoooLG
 * @since 2024-12-10
 */
public interface PaysMapper extends BaseMapper<Pays> {

}
