package com.sdut.service;

import com.sdut.pojo.ListPerson;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author QHaoooLG
 * @since 2024-12-23
 */
public interface IListPersonService extends IService<ListPerson> {

}
