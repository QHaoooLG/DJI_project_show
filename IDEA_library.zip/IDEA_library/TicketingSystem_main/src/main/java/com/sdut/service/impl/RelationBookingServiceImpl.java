package com.sdut.service.impl;

import com.sdut.pojo.RelationBooking;
import com.sdut.mapper.RelationBookingMapper;
import com.sdut.service.IRelationBookingService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author QHaoooLG
 * @since 2024-12-23
 */
@Service
public class RelationBookingServiceImpl extends ServiceImpl<RelationBookingMapper, RelationBooking> implements IRelationBookingService {

}
