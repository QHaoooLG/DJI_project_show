package com.sdut.mapper;

import com.sdut.pojo.Person;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author QHaoooLG
 * @since 2024-12-10
 */
public interface PersonMapper extends BaseMapper<Person> {

}
