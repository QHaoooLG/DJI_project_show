# 数据库系统课程设计-实训

## 数据库系统主题

### 主题名

网上景点门票预订系统

### 功能描述

- 管理员与游客两种角色
管理员:门票管理(增删改查)，景点信息管理(增删改查)
游客:景点信息查看，门票预订，门票支付，退票

---

## SpringBoot 工程设计

### 环境配置

  1. Maven版本: `apache-maven-3.6.3`

  2. 工程中MySQL环境: 
     
     ```yml
     server:
       port: 8088
       servlet:
         context-path: /
     
     spring:
       datasource:
         username: root
         password: root
         url: jdbc:mysql://localhost:3307/ticketing_classdesign?useSSL=false
         type: com.alibaba.druid.pool.DruidDataSource
         driver-class-name: com.mysql.jdbc.Driver
       mvc:
         format:
           date: yyyy-MM-dd
     
     mybatis-plus:
       configuration:
         log-impl: org.apache.ibatis.logging.stdout.StdOutImpl
         map-underscore-to-camel-case: true  # 开启驼峰命名规则
     
     ```
     
  3. pom.dependencies:
        ```xml
        <dependencies>
            <dependency>
                <groupId>org.springframework.boot</groupId>
                <artifactId>spring-boot-starter-web</artifactId>
            </dependency>
        
            <dependency>
                <groupId>org.mybatis.spring.boot</groupId>
                <artifactId>mybatis-spring-boot-starter</artifactId>
                <version>2.1.1</version>
            </dependency>
        
            <dependency>
                <groupId>mysql</groupId>
                <artifactId>mysql-connector-java</artifactId>
                <version>8.0.27</version>
            </dependency>
        
            <!-- mybatisPlus 核心库 -->
            <dependency>
                <groupId>com.baomidou</groupId>
                <artifactId>mybatis-plus-boot-starter</artifactId>
                <version>3.1.0</version>
            </dependency>
        
            <dependency>
                <groupId>org.springframework.boot</groupId>
                <artifactId>spring-boot-devtools</artifactId>
                <scope>runtime</scope>
                <optional>true</optional>
            </dependency>
            
            <!-- https://mvnrepository.com/artifact/org.projectlombok/lombok -->
            <dependency>
                <groupId>org.projectlombok</groupId>
                <artifactId>lombok</artifactId>
                <version>1.18.32</version>
                <scope>provided</scope>
            </dependency>
        
            <dependency>
                <groupId>org.springframework.boot</groupId>
                <artifactId>spring-boot-starter-test</artifactId>
                <scope>test</scope>
                <exclusions>
                    <exclusion>
                        <groupId>org.junit.vintage</groupId>
                        <artifactId>junit-vintage-engine</artifactId>
                    </exclusion>
                </exclusions>
            </dependency>
        
        </dependencies>
        ```





---

### 前端



#### 分角色管理

##### 用户

权限可达页面：

1. 登录页面

   http://localhost:8088/index.html

2. 购票页面

3. 个人信息页

4. 信息查询页

5. 支付页面

##### 管理员

1. 登录页面

   http://localhost:8088/index.html

2. 后台管理操作台页



#### 页面设计

1. 用户界面 index.html
   1. 首页 home.html
   2. 票务功能 service/
      1. 订票 ticketing.html
      2. 退票 rebate.html
      3. 支付 pay
   3. 信息查询 search/
      1. 景点信息 info_sceneries
      2. 订票记录 record_ticketing
      3. 订票人信息 info_persons
      4. 退票记录 record_rebate
      5. 支付记录 record_pay
   4. 个人主页 person.html
2. 后台管理页面 main.html
   1. 业务管理 transaction/
      1. 景点信息 sceneries
      2. 门票信息 tickets
      3. 景点负荷 loads

   2. 用户管理 user/
      1. 订票记录 ticketing
      2. 退票记录 rebates
      3. 支付记录 pays




---

### 后端



#### 功能组件

##### 1 - 登录拦截



##### 2 - 验证码生成





---

### 用户交互





## 数据库设计

### 表设计

```
1. 用户表 user
   1. 用户 id : varchar(255)
   2. 密码 password : varchar(255)
   3. 昵称 nickname : varchar(128)
   4. 性别 sex : varchar(32)
   5. 电话 phone : varchar(128)
   6. 银行卡号 bank : varchar(255)
   7. 注册时间 regtime : date
   8. 权限级别 power : varchar(32)
   9. 用户名 name : varchar(255)
   
2. 景点库 sceneries
   1. 景点 id : varchar(255)
   2. 景点名称 name : varchar(128)
   3. 景点描述 text : varchar(255)
   4. 起始时间 start_date : date
   5. 截止时间 end_date : date
   6. 景点照片 img : varchar(255)
   
3. 门票库 tickets
   1. 门票 id	: varchar(255)
   2. 价格 price : double(32) with 2 points
   3. 余量 num : int(128)
   4. 折扣系数 discount : double(16) with 2 points
   5. 备注 text : varchar(255)
   6. 状态 state : varchar(32)
   7. 起始有效日期 start_date : date
   8. 终止有效日期 end_date : date
   
4. 订票人信息 person
   1. 身份证号 id : varchar(255)
   2. 归属用户 user_id : varchar(255)
   3. 姓名 name : varchar(64)
   4. 电话 phone : varchar(128)
   5. 年龄 age : int(16)
   
5. 订票记录表 bookings
   1. 订票单号 id : varchar(255)
   2. 发起用户 user_id : varchar(255)
   3. 门票 ticket_id : varchar(255)
   4. 景点 scenery_id : varchar(255)
   5. 订票单发起时间 start_time : datetime
   6. 订票单完成时间 end_time : datetime
   7. 订票单状态 state : varchar(32)
   8. 预计支付金额 amount : double(255) with 2 points
   
6. 支付订单表 pays
   1. 支付订单号 id : varchar(255)
   2. 金额 amount : double(255) with 2 points
   3. 支付方式 way : varchar(64)
   4. 支付状态 state : varchar(32)
   5. 支付订单发起时间 start_time : datetime
   6. 支付订单完成时间 end_time : datetime
   
7. 退票记录表 rebates
   1. 退票记录 id : varchar(255)
   2. 退票申请发起时间 start_time : datetime
   3. 退票申请完成时间 end_time : datetime
   4. 审核状态 state : varchar(32)
   
8. 景点-门票中间表 list_ticket
   1. 景点 scenery_id : varchar(255)
   2. 门票 ticket_id : varchar(255)
   
9. 订票人-订单中间表 list_person
   1. 订票单号 booking_id : varchar(255)
   2. 订票人身份证号 person_id : varchar(255)
   
10. 景点负荷表 loads
    1. 景点 scenery_id : varchar(255)
    2. 日期 date : date
    3. 已售门票数 sold : int(128)
    4. 当天最大容纳人数 max : int(128)
    
11. 订单关系表 relation_booking
    1. 订票单号 booking_id : varchar(255)
    2. 支付订单 pay_id : varchar(255)
    3. 退票记录 rebate_id : varchar(255)
```



## 技术难点及相关解决思路

### 前端



### 后端

1. 将Trigger放在数据库中定义，还是在Spring Boot框架下使用代码解决？

   

2. Procedure如何在Spring Boot中编写的各个业务中定义？Procedure in Datebase / Procedure in Spring Boot ?

 

### 数据库模型设计

1. ERA的构建如何更契合实际情况？





## 测试

### 模块测试

#### 身份认证测试用例表

表头：

1. 用例编号
2. 输入
   1. 用户名
   2. 密码
3. 期望反馈
4. 实际反馈
5. 结果

#### 景点管理测试用例表

添加景点数据集：

1. 数据用例编号	
2. 数据字段
   1. 景点编号
   2. 景点名称
   3. 景点描述
   4. 起始日期
   5. 截止日期
   6. 图片文件名

测试用例表：

1. 用例编号
2. 输入数据用例编号
3. 期望反馈
4. 实际反馈
5. 结果



