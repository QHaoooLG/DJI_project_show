// 形状抽象类
abstract class Shape {
    abstract double getArea();

    abstract String getShapeType();
}

// 圆形类
class Circle extends Shape {
    private double radius;

    public Circle(double radius) {
        this.radius = radius;
    }

    @Override
    public double getArea() {
        return Math.PI * radius * radius;
    }

    @Override

    public String getShapeType() {
        return "Circle";
    }
}


//正方形类
class Square extends Shape {
    private double sideLength;

    public Square(double sideLength) {
        this.sideLength = sideLength;
    }

    @override
    public double getArea() {
        return sideLength * sideLength;
    }

    @override
    public String getShapeType() {
        return "Square";
    }
}


//三角形类
class Triangle extends Shape {
    private double side1, side2, side3;

    public Triangle(double side1, double side2, double side3) {
        this.side1 = side1;
        this.side2 = side2;
        this.side3 = side3;
    }

    @override
    public double getArea() {
//使用海伦公式计算三角形面积
        double s = (side1 + side2 + side3) / 2;
        return Math.sqrt(s * (s - side1) * (s - side2) * (s - side3));
        了
        @Override
        public String getShapeType () {
            return "Triangle";
        }
    }

    // 加工参数类
    class Size {
        private double value;

        public Size(double value) {
            this.value = value;
        }

        public double getValue() {
            return value;
        }

        // CAM 工具库类
        class CAMToolLibrary {
            public void processShape(Shape shape, Size size) {
                if (shape.getShapeType().equals("Circle")) {
//处理圆形加工逻辑，这里简单打印
                    System.out.println("Processing Circle with radius: " + size.getValue());
                } else if (shape.getShapeType().equals("Square")) {
                    System.out.println("Processing Square with side length: " + size.getValue());
                } else if (shape.getShapeType().equals("Triangle")) {
                    System.out.println("Processing Triangle with side lengths.");
                } else {
                    throw new IllegalArgumentException("Unsupported shape");
                }

//系统界面类
                class SystemUI {
                    private ProcessingControl control;

                    public SystemUI(ProcessingControl control) {
                        this.control = control;
                    }

                    public void start() {
//模拟获取用户输入，这里假设为圆形，半径为5
                        Shape circle = new Circle(5);
                        Size size = new Size(5);
                        control.process(circle, size);
                    }
                }

//加工控制类
                class ProcessingControl {
                    private CAMToolLibrary toolLibrary;

                    public ProcessingControl(CAMToolLibrary toolLibrary) {
                        this.toolLibrary = toolLibrary;
                    }

                    public void process(Shape shape, Size size) {
                        toolLibrary.processShape(shape, size);
                    }
                }

                public class CAMSystem {
                    public static void main(String[] args) {
                        CAMToolLibrary toolLibrary = new CAMToolLibrary();
                        ProcessingControl control = new ProcessingControl(toolLibrary);
                        SystemUI ui = new SystemUI(control);
                        ui.start();
                    }
                }